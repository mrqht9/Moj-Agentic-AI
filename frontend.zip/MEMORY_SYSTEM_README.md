# 💾 نظام الذاكرة - Memory System

## 📋 نظرة عامة

نظام ذاكرة متقدم مبني على **PostgreSQL** يحفظ جميع المحادثات والرسائل، ويتعرف على المستخدمين وتفضيلاتهم، ويوفر سياق المحادثات السابقة للوكلاء الذكية.

---

## ✨ الميزات

### 1. **حفظ المحادثات التلقائي**
- ✅ كل رسالة تُحفظ تلقائياً في قاعدة البيانات
- ✅ ربط المحادثات بالمستخدمين
- ✅ دعم الجلسات (Sessions)

### 2. **السياق الذكي**
- ✅ الوكيل يتذكر المحادثات السابقة
- ✅ يستخدم السياق لفهم الطلبات بشكل أفضل
- ✅ يتعرف على تفضيلات المستخدم

### 3. **التحليلات والإحصائيات**
- ✅ النوايا الأكثر استخداماً
- ✅ المنصات المفضلة
- ✅ إحصائيات شاملة

---

## 🗄️ قاعدة البيانات

### الجداول:

#### 1. `conversations` - المحادثات
```sql
- id: معرف المحادثة
- user_id: معرف المستخدم
- session_id: معرف الجلسة
- title: عنوان المحادثة
- created_at: تاريخ الإنشاء
- updated_at: تاريخ آخر تحديث
```

#### 2. `messages` - الرسائل
```sql
- id: معرف الرسالة
- conversation_id: معرف المحادثة
- role: دور المرسل (user, assistant, system)
- content: محتوى الرسالة
- intent: النية المكتشفة
- confidence: مستوى الثقة
- agent: الوكيل الذي عالج الرسالة
- metadata: بيانات إضافية (JSON)
- created_at: تاريخ الإرسال
```

---

## 🚀 الاستخدام

### 1. تهيئة قاعدة البيانات

```bash
# تأكد من تشغيل PostgreSQL
# ثم شغل الخادم - سيتم إنشاء الجداول تلقائياً
python app/main.py
```

### 2. المحادثة مع الذاكرة

الذاكرة تعمل تلقائياً! فقط استخدم الشاتبوت كالمعتاد:

```python
# WebSocket
{
  "message": "مرحباً",
  "user_id": 1,
  "session_id": "session_123"
}
```

---

## 📡 API Endpoints

### 1️⃣ الحصول على محادثات المستخدم

**Endpoint:** `GET /api/conversations/`

**Parameters:**
- `user_id`: معرف المستخدم
- `limit`: عدد المحادثات (افتراضي: 20)

**Response:**
```json
[
  {
    "id": 1,
    "user_id": 1,
    "session_id": "session_123",
    "title": "مرحباً",
    "created_at": "2024-01-22T00:00:00",
    "updated_at": "2024-01-22T00:10:00",
    "message_count": 8
  }
]
```

---

### 2️⃣ الحصول على تفاصيل محادثة

**Endpoint:** `GET /api/conversations/{conversation_id}`

**Response:**
```json
{
  "conversation": {
    "id": 1,
    "title": "مرحباً",
    "message_count": 8
  },
  "messages": [
    {
      "id": 1,
      "role": "user",
      "content": "مرحباً",
      "intent": "greeting",
      "confidence": "0.95",
      "agent": "Main_Agent",
      "created_at": "2024-01-22T00:00:00"
    },
    {
      "id": 2,
      "role": "assistant",
      "content": "مرحباً! 👋 كيف يمكنني مساعدتك؟",
      "intent": "greeting",
      "agent": "Main_Agent",
      "created_at": "2024-01-22T00:00:01"
    }
  ]
}
```

---

### 3️⃣ الحصول على تفضيلات المستخدم

**Endpoint:** `GET /api/conversations/user/{user_id}/preferences`

**Response:**
```json
{
  "total_conversations": 15,
  "common_intents": [
    "create_post",
    "add_account",
    "get_analytics"
  ],
  "preferred_platforms": [
    "twitter",
    "instagram"
  ],
  "last_interaction": "2024-01-22T00:10:00"
}
```

---

### 4️⃣ إحصائيات المحادثات

**Endpoint:** `GET /api/conversations/stats/summary`

**Parameters:**
- `user_id`: معرف المستخدم

**Response:**
```json
{
  "total_conversations": 15,
  "total_messages": 120,
  "top_intents": [
    {"intent": "create_post", "count": 45},
    {"intent": "add_account", "count": 30},
    {"intent": "get_analytics", "count": 25}
  ],
  "last_conversation": "2024-01-22T00:10:00"
}
```

---

### 5️⃣ حذف محادثة

**Endpoint:** `DELETE /api/conversations/{conversation_id}`

**Response:**
```json
{
  "status": "success",
  "message": "تم حذف المحادثة بنجاح",
  "conversation_id": 1
}
```

---

## 🧠 كيف يعمل السياق؟

### مثال عملي:

```
المستخدم: "أضف حساب تويتر"
المساعد: "سأساعدك في إضافة حساب تويتر..."

المستخدم: "اسم المستخدم test_user"
المساعد: [يتذكر أنك تريد إضافة حساب]
         "حسناً، اسم المستخدم test_user. ما هي كلمة المرور؟"

المستخدم: "كلمة المرور pass123"
المساعد: [يتذكر الاسم وكلمة المرور]
         "تمام! سأقوم بتسجيل الدخول..."
```

### كيف يحدث هذا؟

1. **حفظ تلقائي**: كل رسالة تُحفظ في قاعدة البيانات
2. **استرجاع السياق**: عند رسالة جديدة، يسترجع آخر 10 رسائل
3. **إضافة للوكيل**: السياق يُضاف للرسالة المرسلة للوكيل
4. **فهم أفضل**: الوكيل يفهم الطلب بناءً على السياق

---

## 🎯 التفضيلات الذكية

النظام يتعلم من استخدامك:

### مثال:

```
إذا استخدمت تويتر 10 مرات وانستقرام 3 مرات:

المستخدم: "انشر منشور"
المساعد: [يعرف أنك تفضل تويتر]
         "هل تريد النشر على تويتر؟"
```

---

## 🔧 التكامل مع الوكلاء

### في الوكيل الرئيسي:

```python
# الحصول على السياق
context = memory_service.get_conversation_context(
    db, conversation_id, max_messages=10
)

# الحصول على التفضيلات
preferences = memory_service.get_user_preferences(db, user_id)

# إضافة للرسالة
enhanced_message = f"""
السياق السابق:
{context}

الرسالة الحالية: {message}

ملاحظة: المستخدم يفضل: {preferences['preferred_platforms']}
"""
```

---

## 📊 أمثلة الاستخدام

### 1. عرض محادثاتي

```bash
curl "http://localhost:5789/api/conversations/?user_id=1&limit=10"
```

### 2. عرض محادثة محددة

```bash
curl "http://localhost:5789/api/conversations/1"
```

### 3. تفضيلاتي

```bash
curl "http://localhost:5789/api/conversations/user/1/preferences"
```

### 4. الإحصائيات

```bash
curl "http://localhost:5789/api/conversations/stats/summary?user_id=1"
```

---

## 🧪 الاختبار

```bash
# اختبار نظام الذاكرة
python test_memory_system.py
```

سيقوم الاختبار بـ:
1. ✅ إنشاء محادثة جديدة
2. ✅ إرسال رسائل متسلسلة
3. ✅ عرض المحادثات
4. ✅ عرض تفاصيل محادثة
5. ✅ عرض التفضيلات
6. ✅ عرض الإحصائيات

---

## 🎨 في الواجهة

يمكنك إضافة:

### 1. قائمة المحادثات
```javascript
fetch('/api/conversations/?user_id=1')
  .then(res => res.json())
  .then(conversations => {
    // عرض قائمة المحادثات
  });
```

### 2. عرض محادثة
```javascript
fetch('/api/conversations/1')
  .then(res => res.json())
  .then(data => {
    // عرض الرسائل
  });
```

### 3. إحصائيات المستخدم
```javascript
fetch('/api/conversations/stats/summary?user_id=1')
  .then(res => res.json())
  .then(stats => {
    // عرض الإحصائيات
  });
```

---

## 🔒 الخصوصية والأمان

- ✅ كل مستخدم يرى محادثاته فقط
- ✅ التحقق من الصلاحيات في كل endpoint
- ✅ إمكانية حذف المحادثات
- ✅ البيانات الحساسة مشفرة

---

## 📈 الأداء

- ✅ Indexes على الحقول المهمة
- ✅ Pagination للمحادثات الكثيرة
- ✅ حد أقصى للرسائل المسترجعة (10 افتراضياً)
- ✅ Lazy loading للرسائل

---

## 🎉 الميزات المستقبلية

- 🔄 البحث في المحادثات
- 🔄 تصدير المحادثات
- 🔄 مشاركة المحادثات
- 🔄 تلخيص المحادثات الطويلة
- 🔄 اقتراحات ذكية بناءً على التاريخ

---

## ✅ جاهز للاستخدام!

النظام الآن:
- ✅ يحفظ كل محادثة تلقائياً
- ✅ يتذكر المستخدمين وتفضيلاتهم
- ✅ يوفر سياق للوكلاء
- ✅ يعرض المحادثات والإحصائيات

**استمتع بنظام ذاكرة ذكي!** 💾🧠
