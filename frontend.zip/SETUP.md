# 🚀 دليل التثبيت السريع - موج AI 

## الخطوة 1️⃣: تثبيت Python

تأكد من تثبيت Python 3.11 أو أحدث:
```bash
python --version
```

## الخطوة 2️⃣: إنشاء بيئة افتراضية (اختياري لكن موصى به)

```bash
python -m venv venv
```

### تفعيل البيئة الافتراضية:

**Windows:**
```bash
venv\Scripts\activate
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

## الخطوة 3️⃣: تثبيت المكتبات

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

## الخطوة 4️⃣: تثبيت Playwright

```bash
playwright install
```

## الخطوة 5️⃣: إعداد ملف البيئة

1. انسخ محتوى `.env.example` وأنشئ ملف جديد باسم `.env`
2. أضف مفتاح OpenAI API الخاص بك:

```env
OPENAI_API_KEY=sk-your-actual-api-key-here
```

### 🔑 كيفية الحصول على OpenAI API Key:

1. اذهب إلى: https://platform.openai.com/api-keys
2. سجل دخول أو أنشئ حساب
3. اضغط على "Create new secret key"
4. انسخ المفتاح وضعه في ملف `.env`

## الخطوة 6️⃣: تشغيل التطبيق

### الطريقة الأولى (الأسهل):
```bash
python run.py
```

### الطريقة الثانية:
```bash
python -m app.main
```

### الطريقة الثالثة:
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## الخطوة 7️⃣: فتح المتصفح

افتح المتصفح على:
```
http://localhost:8000
```

## ✅ اختبار التطبيق

1. يجب أن تظهر واجهة الشات
2. اكتب رسالة واضغط Enter
3. يجب أن يرد المساعد الذكي

## ❌ حل المشاكل الشائعة

### المشكلة: ModuleNotFoundError

**الحل:**
```bash
pip install -r requirements.txt
```

### المشكلة: خطأ في الاتصال بـ OpenAI

**الحل:**
- تأكد من إضافة `OPENAI_API_KEY` في ملف `.env`
- تأكد من صحة المفتاح
- تأكد من وجود رصيد في حسابك على OpenAI

### المشكلة: Port 8000 is already in use

**الحل:**
```bash
# استخدم منفذ آخر
uvicorn app.main:app --reload --port 8001
```

### المشكلة: خطأ في Playwright

**الحل:**
```bash
playwright install
playwright install-deps  # Linux فقط
```

## 📦 المكتبات الأساسية المطلوبة

- `fastapi` - Web framework
- `uvicorn` - ASGI server
- `openai` - OpenAI API client
- `websockets` - WebSocket support
- `python-dotenv` - Environment variables
- `pydantic-settings` - Settings management

## 🎯 الخطوات التالية

بعد التشغيل الناجح:
1. جرّب إرسال رسائل مختلفة
2. اختبر الوضع الليلي/النهاري
3. جرّب نسخ الكود من الردود
4. اختبر على الهاتف (responsive design)

## 📞 الدعم

إذا واجهت مشاكل:
1. تأكد من تثبيت جميع المكتبات
2. تأكد من صحة ملف `.env`
3. افحص logs في Terminal
4. افحص Console في المتصفح (F12)

---

**مبروك! 🎉 تطبيق الشات بوت جاهز للاستخدام**
