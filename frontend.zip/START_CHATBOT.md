# 🚀 تشغيل الشاتبوت مع نظام الوكلاء

## ✅ الإعدادات جاهزة!

تم تكوين النظام بنجاح:
- ✅ OpenAI API Key مضاف
- ✅ النموذج: gpt-4o-mini
- ✅ نظام الوكلاء متكامل مع WebSocket

---

## 🎯 خطوات التشغيل

### 1. تشغيل الخادم

```bash
cd c:\Users\engsa\Desktop\mojv1
python app/main.py
```

**يجب أن ترى:**
```
Database initialized
AI Agents initialized successfully
INFO:     Uvicorn running on http://0.0.0.0:5789
```

---

### 2. فتح واجهة الشات

افتح المتصفح وانتقل إلى:
```
http://localhost:5789/
```

---

## 💬 أمثلة للتجربة

جرب هذه الرسائل في الشاتبوت:

### 1. التحية
```
مرحباً
```
**النتيجة المتوقعة:** رد ترحيبي من الوكيل الرئيسي

---

### 2. طلب المساعدة
```
ساعدني
```
**النتيجة المتوقعة:** قائمة بالميزات المتاحة

---

### 3. إضافة حساب X
```
أضف حساب تويتر
```
**النتيجة المتوقعة:** 
- تحليل النية: `add_account`
- الوكيل: `X_Agent`
- طلب بيانات الاعتماد

---

### 4. نشر تغريدة
```
انشر تغريدة 'مرحباً بالجميع!'
```
**النتيجة المتوقعة:**
- تحليل النية: `create_post`
- الوكيل: `X_Agent`
- استخراج المحتوى: "مرحباً بالجميع!"

---

### 5. طلب الإحصائيات
```
أرني إحصائيات حسابي
```
**النتيجة المتوقعة:**
- تحليل النية: `get_analytics`
- الوكيل: `Main_Agent`

---

## 🔍 مراقبة النظام

### في Terminal سترى:

```
INFO: User message received: "مرحباً"
INFO: Intent detected: greeting (confidence: 0.95)
INFO: Agent: Main_Agent
INFO: Response sent
```

---

## 🐛 استكشاف الأخطاء

### المشكلة: "AI Agents initialization failed"

**الحل:**
```bash
# تحقق من ملف .env.agents
cat .env.agents

# تأكد من:
# 1. OPENAI_API_KEY صحيح
# 2. OPENAI_MODEL = gpt-4o-mini (أو gpt-4)
```

---

### المشكلة: "Chat interface not found"

**الحل:**
```bash
# تحقق من وجود ملف chat.html
ls templates/chat.html

# إذا لم يكن موجوداً، سيتم إنشاؤه تلقائياً
```

---

### المشكلة: الشاتبوت لا يرد

**الحل:**
1. افتح Console في المتصفح (F12)
2. تحقق من WebSocket connection
3. راجع Terminal للأخطاء

---

## 📊 تدفق العمل

```
المستخدم يكتب رسالة
        ↓
WebSocket (/ws/chat)
        ↓
Agent Manager
        ↓
تحليل النية (Intent System)
        ↓
توجيه للوكيل المناسب
   ↓              ↓
Main Agent    X Agent
        ↓
تنفيذ الأدوات (Tools)
        ↓
إرجاع النتيجة
        ↓
عرض في الواجهة
```

---

## 🎨 معلومات الرد

كل رد من الوكيل يحتوي على:

```json
{
  "type": "assistant_message",
  "message": "رد الوكيل",
  "metadata": {
    "intent": "add_account",
    "confidence": 0.95,
    "agent": "X_Agent"
  },
  "timestamp": "2024-01-21T23:00:00"
}
```

---

## 🔧 اختبار سريع

### اختبار من Terminal:

```bash
# اختبار Agent API
python test_agents_api.py

# اختبار محلي
python test_agents.py
```

### اختبار من المتصفح:

1. افتح Developer Tools (F12)
2. اذهب إلى Console
3. جرب:
```javascript
// إرسال رسالة
const ws = new WebSocket('ws://localhost:5789/ws/chat');
ws.onopen = () => {
  ws.send(JSON.stringify({
    message: "مرحباً",
    user_id: 1
  }));
};
ws.onmessage = (event) => {
  console.log('Received:', JSON.parse(event.data));
};
```

---

## ✅ جاهز للاستخدام!

الآن يمكنك:
1. ✅ التحدث مع الشاتبوت
2. ✅ تحليل النوايا تلقائياً
3. ✅ إدارة حسابات X
4. ✅ نشر تغريدات
5. ✅ تحديث الملفات الشخصية

---

## 📞 للدعم

- راجع `AGENTS_README.md` للتفاصيل الكاملة
- راجع `INTENT_API_README.md` لنظام تحليل النوايا
- افحص logs في Terminal

**استمتع بالشاتبوت الذكي!** 🎉
