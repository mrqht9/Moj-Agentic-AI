# 🤖 نظام الوكلاء الذكية - AI Agents System

## 📋 نظرة عامة

نظام وكلاء ذكية متقدم مبني على **AutoGen** يتيح لك إدارة منصات التواصل الاجتماعي بذكاء اصطناعي.

### المكونات الرئيسية:

1. **الوكيل الرئيسي (Main Agent)** - ينسق العمل ويحلل النوايا
2. **وكيل X (X Agent)** - متخصص في إدارة منصة X/Twitter
3. **نظام تحليل النوايا (Intent System)** - يفهم طلبات المستخدم
4. **أدوات متخصصة (Tools)** - تنفذ المهام الفعلية

---

## 🚀 البدء السريع

### 1. التثبيت

المكتبات مثبتة بالفعل! ✅

### 2. الإعدادات

انسخ ملف `.env.agents` وعدل الإعدادات:

```bash
cp .env.agents .env
```

**إعدادات OpenAI:**
```env
LLM_API_TYPE=openai
OPENAI_API_KEY=sk-your-key-here
OPENAI_MODEL=gpt-4
```

**أو استخدم نموذج محلي (Ollama):**
```env
LLM_API_TYPE=ollama
OLLAMA_MODEL=llama2
OLLAMA_BASE_URL=http://localhost:11434/v1
```

### 3. التشغيل

```bash
# تشغيل الخادم
python app/main.py

# في نافذة أخرى - اختبار النظام
python test_agents.py
```

---

## 🎯 كيف يعمل النظام؟

### تدفق العمل:

```
المستخدم
   ↓
   📝 "أضف حساب تويتر"
   ↓
الوكيل الرئيسي (Main Agent)
   ↓
   🎯 تحليل النية → "add_account"
   ↓
   🌐 تحديد المنصة → "twitter/x"
   ↓
وكيل X (X Agent)
   ↓
   🔧 استخدام أداة x_login
   ↓
   ✅ تنفيذ العملية
   ↓
   📤 إرجاع النتيجة
```

---

## 📡 API Endpoints

### 1️⃣ إرسال رسالة للوكيل

**Endpoint:** `POST /api/agent/message`

**Request:**
```json
{
  "message": "أضف حساب تويتر باسم test_user",
  "user_id": 1,
  "context": {}
}
```

**Response:**
```json
{
  "success": true,
  "message": "سأقوم بإضافة حساب تويتر لك...",
  "intent_result": {
    "intent": "add_account",
    "confidence": 0.95,
    "platform": "twitter",
    "entities": {}
  },
  "agent": "X_Agent",
  "timestamp": "2024-01-21T23:00:00"
}
```

### 2️⃣ فحص صحة النظام

**Endpoint:** `GET /api/agent/health`

**Response:**
```json
{
  "status": "healthy",
  "main_agent": "initialized",
  "timestamp": "2024-01-21T23:00:00"
}
```

### 3️⃣ إعادة تعيين النظام

**Endpoint:** `POST /api/agent/reset`

---

## 🛠️ الوكلاء والأدوات

### الوكيل الرئيسي (Main Agent)

**المهام:**
- استقبال رسائل المستخدمين
- تحليل النوايا باستخدام Intent System
- توجيه الطلبات للوكلاء الفرعيين
- تنسيق العمل بين الوكلاء

**الأدوات:**
- `detect_user_intent` - تحليل نية المستخدم

---

### وكيل X (X Agent)

**المهام:**
- تسجيل الدخول إلى حسابات X
- نشر التغريدات
- تحديث الملف الشخصي
- إدارة الحسابات المتعددة

**الأدوات:**

#### 1. `x_login` - تسجيل الدخول
```python
{
  "username": "test_user",
  "password": "password123",
  "label": "my_account",
  "headless": true
}
```

#### 2. `x_post` - نشر تغريدة
```python
{
  "label": "my_account",
  "text": "مرحباً بالجميع!",
  "media_path": "/path/to/image.jpg"  # اختياري
}
```

#### 3. `x_update_profile` - تحديث الملف الشخصي
```python
{
  "label": "my_account",
  "name": "اسم جديد",
  "bio": "سيرة ذاتية جديدة",
  "banner_path": "/path/to/banner.jpg",
  "avatar_path": "/path/to/avatar.jpg"
}
```

---

## 💬 أمثلة الاستخدام

### مثال 1: إضافة حساب

**Input:**
```json
{
  "message": "أضف حساب تويتر باسم المستخدم test_user وكلمة المرور pass123"
}
```

**Output:**
```json
{
  "success": true,
  "message": "تم تسجيل الدخول بنجاح وحفظ الحساب",
  "agent": "X_Agent"
}
```

---

### مثال 2: نشر تغريدة

**Input:**
```json
{
  "message": "انشر تغريدة 'مرحباً بالجميع!' على حساب test_user"
}
```

**Output:**
```json
{
  "success": true,
  "message": "تم نشر التغريدة بنجاح",
  "agent": "X_Agent"
}
```

---

### مثال 3: تحديث الملف الشخصي

**Input:**
```json
{
  "message": "حدث الملف الشخصي بالاسم 'اسم جديد' والسيرة 'مطور برمجيات'"
}
```

**Output:**
```json
{
  "success": true,
  "message": "تم تحديث الملف الشخصي بنجاح",
  "agent": "X_Agent"
}
```

---

### مثال 4: المساعدة

**Input:**
```json
{
  "message": "ساعدني"
}
```

**Output:**
```json
{
  "success": true,
  "message": "مرحباً! يمكنني مساعدتك في:\n\n📱 إدارة الحسابات...",
  "agent": "Main_Agent"
}
```

---

## 🔧 الهيكل البرمجي

```
app/
├── agents/
│   ├── __init__.py
│   ├── main_agent.py       # الوكيل الرئيسي
│   ├── x_agent.py          # وكيل منصة X
│   ├── tools.py            # الأدوات المشتركة
│   ├── config.py           # الإعدادات
│   └── agent_manager.py    # مدير الوكلاء (Singleton)
│
├── api/
│   └── agent_routes.py     # API endpoints
│
└── services/
    └── intent_service.py   # خدمة تحليل النوايا
```

---

## 🎨 التكامل مع n8n

### Workflow مقترح:

```
1. [Webhook] استقبال رسالة المستخدم
   ↓
2. [HTTP Request] إرسال للوكيل
   POST http://localhost:5789/api/agent/message
   Body: {"message": "={{$json.message}}"}
   ↓
3. [Function] معالجة الرد
   const response = $json.message;
   const intent = $json.intent_result.intent;
   ↓
4. [Switch] توجيه حسب النتيجة
   - success = true → إرسال رد إيجابي
   - success = false → إرسال رسالة خطأ
   ↓
5. [Respond to Webhook] إرسال الرد
```

### مثال HTTP Request في n8n:

```javascript
// Method: POST
// URL: http://localhost:5789/api/agent/message
// Body:
{
  "message": "={{$json.user_message}}",
  "user_id": "={{$json.user_id}}"
}

// Response:
// استخدم {{$json.message}} للحصول على رد الوكيل
// استخدم {{$json.intent_result.intent}} لمعرفة النية
// استخدم {{$json.agent}} لمعرفة الوكيل الذي عالج الطلب
```

---

## 🔑 المتغيرات البيئية

### إعدادات LLM:

| المتغير | الوصف | القيمة الافتراضية |
|---------|-------|-------------------|
| `LLM_API_TYPE` | نوع API (openai, azure, ollama, lmstudio) | `openai` |
| `OPENAI_API_KEY` | مفتاح OpenAI API | - |
| `OPENAI_MODEL` | نموذج OpenAI | `gpt-4` |
| `LLM_TEMPERATURE` | درجة الإبداع (0-1) | `0.7` |
| `LLM_TIMEOUT` | مهلة الطلب (ثواني) | `120` |

### إعدادات الوكلاء:

| المتغير | الوصف | القيمة الافتراضية |
|---------|-------|-------------------|
| `AGENT_MAX_REPLIES` | أقصى عدد ردود تلقائية | `10` |
| `AGENT_HUMAN_INPUT_MODE` | وضع التدخل البشري | `NEVER` |

---

## 🐛 استكشاف الأخطاء

### المشكلة: "خطأ في التهيئة"

**الحل:**
1. تحقق من ملف `.env.agents`
2. تأكد من صحة `OPENAI_API_KEY`
3. أو استخدم نموذج محلي (Ollama)

### المشكلة: "الوكيل لا يستجيب"

**الحل:**
1. تحقق من تشغيل الخادم: `python app/main.py`
2. افحص صحة النظام: `GET /api/agent/health`
3. أعد تعيين النظام: `POST /api/agent/reset`

### المشكلة: "فشل تسجيل الدخول إلى X"

**الحل:**
1. تحقق من صحة بيانات الاعتماد
2. تأكد من تشغيل X API: `http://localhost:5789/api/login`
3. راجع ملف `app/x/modules/x_login.py`

---

## 📊 النوايا المدعومة

### إدارة الحسابات:
- `add_account` - إضافة حساب
- `remove_account` - حذف حساب
- `list_accounts` - عرض الحسابات
- `switch_account` - التبديل بين الحسابات

### إدارة المحتوى:
- `create_post` - نشر منشور
- `schedule_post` - جدولة منشور
- `delete_post` - حذف منشور
- `edit_post` - تعديل منشور

### التحليلات:
- `get_analytics` - عرض الإحصائيات
- `get_engagement` - معدل التفاعل
- `get_followers` - عدد المتابعين

### عام:
- `help` - المساعدة
- `greeting` - تحية

---

## 🚀 التطوير المستقبلي

### وكلاء قادمة:
- ✅ X Agent (مكتمل)
- 🔄 Instagram Agent (قريباً)
- 🔄 Facebook Agent (قريباً)
- 🔄 LinkedIn Agent (قريباً)

### ميزات قادمة:
- 🔄 جدولة المنشورات التلقائية
- 🔄 تحليلات متقدمة
- 🔄 الرد التلقائي على التعليقات
- 🔄 إدارة الحملات الإعلانية

---

## 📞 الدعم

للمزيد من المعلومات:
- `test_agents.py` - أمثلة الاختبار
- `app/agents/` - كود الوكلاء
- `INTENT_API_README.md` - دليل Intent System

---

## ✅ جاهز للاستخدام!

النظام جاهز الآن! 🎉

**الخطوات التالية:**
1. عدل ملف `.env.agents` بمفتاح API الخاص بك
2. شغل الخادم: `python app/main.py`
3. اختبر النظام: `python test_agents.py`
4. ادمج مع n8n أو واجهتك الخاصة

**استمتع بإدارة منصات التواصل بذكاء اصطناعي!** 🚀
