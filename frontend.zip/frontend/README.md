# 🚀 موج AI - React Frontend

واجهة React حديثة لنظام إدارة وسائل التواصل الاجتماعي بالذكاء الاصطناعي مع TailwindCSS و Axios.

## 📦 المكتبات المثبتة

- ✅ **React 18.2.0** - مكتبة UI
- ✅ **axios 1.6.5** - HTTP client للاتصال بالـ API
- ✅ **react-icons 5.0.1** - مكتبة الأيقونات
- ✅ **tailwindcss 3.4.1** - CSS framework
- ✅ **Vite 5.0.8** - Build tool سريع

## 🚀 التشغيل

### 1. تثبيت المكتبات (تم بالفعل)
```bash
npm install
```

### 2. تشغيل Frontend
```bash
npm run dev
```

سيعمل على: **http://localhost:3000**

### 3. تشغيل Backend (في terminal منفصل)
```bash
cd ..
python run.py
```

سيعمل على: **http://localhost:8000**

## 📁 بنية المشروع

```
frontend/
├── src/
│   ├── components/
│   │   ├── ChatInterface.jsx    # الواجهة الرئيسية
│   │   ├── Sidebar.jsx          # الشريط الجانبي
│   │   ├── MessageList.jsx      # قائمة الرسائل
│   │   ├── Message.jsx          # رسالة واحدة
│   │   ├── MessageInput.jsx     # صندوق الإدخال
│   │   └── TypingIndicator.jsx  # مؤشر الكتابة
│   ├── App.jsx                  # المكون الرئيسي
│   ├── main.jsx                 # نقطة الدخول
│   └── index.css                # Tailwind styles
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
└── postcss.config.js
```

## 🎯 المميزات

- ✅ واجهة عربية RTL كاملة
- ✅ الوضع الليلي/النهاري
- ✅ WebSocket للاتصال الفوري
- ✅ تصميم متجاوب
- ✅ نسخ الرسائل والكود
- ✅ مؤشر الكتابة
- ✅ أيقونات React Icons
- ✅ Axios للـ API calls

## 🔧 Scripts المتاحة

```bash
# تشغيل في وضع التطوير
npm run dev

# بناء للإنتاج
npm run build

# معاينة البناء
npm run preview

# فحص الكود
npm run lint
```

## 🌐 الاتصال بالـ Backend

Frontend يتصل بـ Backend عبر:
- **WebSocket**: `ws://localhost:8000/ws/chat`
- **HTTP API**: `http://localhost:8000/api/*`

تم إعداد Vite proxy تلقائياً في `vite.config.js`.

## 🎨 Tailwind Configuration

الألوان المخصصة:
- `primary`: #0db9f2
- `background-light`: #f5f8f8
- `background-dark`: #101e22
- `sidebar-light`: #f0f4f6
- `sidebar-dark`: #0d181c

## 📝 ملاحظات

- تأكد من تشغيل Backend قبل Frontend
- WebSocket يعيد الاتصال تلقائياً عند الانقطاع
- جميع المكونات responsive وتعمل على الهاتف

## 🐛 حل المشاكل

### المشكلة: لا يتصل بالـ Backend
**الحل**: تأكد من تشغيل Backend على المنفذ 8000

### المشكلة: خطأ في Tailwind
**الحل**: تأكد من تثبيت جميع المكتبات بـ `npm install`

---

**صُنع بـ ❤️ باستخدام React + Vite + TailwindCSS**
