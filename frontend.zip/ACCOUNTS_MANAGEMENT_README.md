# 📋 نظام إدارة الحسابات - Accounts Management System

## 🎯 نظرة عامة

نظام متكامل لإدارة حسابات وسائل التواصل الاجتماعي مع دعم منصات متعددة، مرتبط بالمستخدمين ومحفوظ في قاعدة البيانات.

---

## 🗄️ قاعدة البيانات

### جدول `social_accounts`

```sql
- id: معرف الحساب
- user_id: معرف المستخدم (مرتبط بجدول users)
- platform: المنصة (x, instagram, facebook, linkedin, tiktok)
- username: اسم المستخدم
- display_name: الاسم المعروض
- account_label: تسمية مخصصة للحساب
- cookie_filename: اسم ملف الكوكيز
- status: الحالة (active, inactive, expired, error)
- last_login: آخر تسجيل دخول
- last_used: آخر استخدام
- error_message: رسالة الخطأ (إن وجدت)
- metadata: معلومات إضافية (JSON)
- created_at: تاريخ الإنشاء
- updated_at: تاريخ التحديث
```

---

## 🔌 API Endpoints

### 👤 للمستخدمين (User APIs)

#### 1. الحصول على حساباتي
```http
GET /api/my/accounts
Query Parameters:
  - platform: x, instagram, facebook (اختياري)
  - status: active, inactive, expired, error (اختياري)
```

**Response:**
```json
[
  {
    "id": 1,
    "platform": "x",
    "username": "Ga6rsah",
    "display_name": "Ga6rsah",
    "account_label": "Ga6rsah",
    "status": "active",
    "last_login": "2026-01-22T00:00:00",
    "last_used": "2026-01-22T00:30:00",
    "created_at": "2026-01-22T00:00:00"
  }
]
```

#### 2. إحصائيات حساباتي
```http
GET /api/my/accounts/stats
```

**Response:**
```json
{
  "total": 5,
  "active": 3,
  "inactive": 1,
  "expired": 1,
  "error": 0,
  "by_platform": {
    "x": 3,
    "instagram": 2
  }
}
```

#### 3. تفاصيل حساب معين
```http
GET /api/my/accounts/{account_id}
```

#### 4. حذف حساب
```http
DELETE /api/my/accounts/{account_id}
```

**Response:**
```json
{
  "success": true,
  "message": "تم حذف الحساب Ga6rsah على x",
  "account_id": 1
}
```

---

### 🔐 للإدارة (Admin APIs)

#### 1. الحصول على جميع الحسابات
```http
GET /api/admin/accounts
Query Parameters:
  - platform: x, instagram, facebook (اختياري)
  - status: active, inactive, expired, error (اختياري)
  - limit: الحد الأقصى للنتائج (افتراضي: 100)
```

**Response:**
```json
[
  {
    "id": 1,
    "user_id": 5,
    "user_email": "user@example.com",
    "user_name": "محمد",
    "platform": "x",
    "username": "Ga6rsah",
    "display_name": "Ga6rsah",
    "account_label": "Ga6rsah",
    "status": "active",
    "last_login": "2026-01-22T00:00:00",
    "last_used": "2026-01-22T00:30:00",
    "error_message": null,
    "created_at": "2026-01-22T00:00:00",
    "updated_at": "2026-01-22T00:30:00"
  }
]
```

#### 2. إحصائيات جميع الحسابات
```http
GET /api/admin/accounts/stats
```

#### 3. حسابات مستخدم معين
```http
GET /api/admin/accounts/user/{user_id}
```

#### 4. حذف حساب (إدارة)
```http
DELETE /api/admin/accounts/{account_id}
```

#### 5. تحديث حالة حساب
```http
PATCH /api/admin/accounts/{account_id}/status
Query Parameters:
  - status: active, inactive, expired, error
  - error_message: رسالة الخطأ (اختياري)
```

---

## 🤖 التكامل مع الوكلاء

### تسجيل الدخول التلقائي

عند تسجيل الدخول عبر الوكيل:
```
سجل دخول اليوزر Ga6rsah الباسورد Mm8221809--
```

يتم:
1. ✅ تسجيل الدخول باستخدام Playwright
2. ✅ حفظ الكوكيز في `app/x/cookies/`
3. ✅ **حفظ الحساب في قاعدة البيانات تلقائياً**
4. ✅ ربط الحساب بالمستخدم الحالي

---

## 📊 حالات الحساب (Account Status)

| الحالة | الوصف |
|--------|-------|
| `active` | الحساب نشط ويعمل |
| `inactive` | الحساب غير نشط مؤقتاً |
| `expired` | الجلسة منتهية - يحتاج إعادة تسجيل دخول |
| `error` | حدث خطأ في الحساب |

---

## 🔄 التحديث التلقائي

### عند تسجيل الدخول:
- `status` → `active`
- `last_login` → الآن
- `error_message` → `null`

### عند الاستخدام:
- `last_used` → الآن

### عند حدوث خطأ:
- `status` → `error` أو `expired`
- `error_message` → تفاصيل الخطأ

---

## 🗑️ حذف الحساب

عند حذف حساب:
1. ✅ حذف السجل من قاعدة البيانات
2. ✅ حذف ملف الكوكيز من `app/x/cookies/`
3. ✅ تحديث الإحصائيات

---

## 💬 المحادثات

### جدول `conversations`
- مرتبط بالمستخدم (`user_id`)
- يحفظ جميع المحادثات
- يتتبع الجلسات (`session_id`)

### جدول `messages`
- مرتبط بالمحادثة (`conversation_id`)
- يحفظ كل رسالة (مستخدم/مساعد)
- يحفظ النية والثقة والوكيل المستخدم

### API Endpoints للمحادثات:
```http
GET /api/conversations/              # جميع محادثاتي
GET /api/conversations/{id}          # تفاصيل محادثة
GET /api/conversations/stats/summary # إحصائيات
```

---

## 🎨 لوحة التحكم (Frontend)

### صفحات مقترحة:

#### 1. **صفحة الحسابات** (`/accounts`)
- عرض جميع الحسابات
- تصفية حسب المنصة والحالة
- إضافة حساب جديد
- حذف حساب

#### 2. **صفحة المحادثات** (`/conversations`)
- عرض جميع المحادثات
- البحث في المحادثات
- عرض تفاصيل محادثة

#### 3. **لوحة الإدارة** (`/admin/accounts`)
- عرض جميع حسابات المستخدمين
- إحصائيات شاملة
- إدارة الحسابات (تفعيل/تعطيل/حذف)

---

## 🔐 الصلاحيات

### المستخدم العادي:
- ✅ عرض حساباته فقط
- ✅ إضافة حساب جديد
- ✅ حذف حساباته
- ✅ عرض محادثاته

### الإدارة:
- ✅ عرض جميع الحسابات
- ✅ عرض حسابات أي مستخدم
- ✅ حذف أي حساب
- ✅ تحديث حالة أي حساب
- ✅ عرض الإحصائيات الشاملة

---

## 📝 أمثلة الاستخدام

### Python (Backend)
```python
from app.services.account_service import account_service
from app.db.database import get_db

db = next(get_db())

# إنشاء حساب
account = account_service.create_account(
    db=db,
    user_id=1,
    platform="x",
    username="test_user",
    account_label="حسابي الرئيسي"
)

# الحصول على حسابات المستخدم
accounts = account_service.get_user_accounts(
    db=db,
    user_id=1,
    platform="x"
)

# حذف حساب
success = account_service.delete_account(
    db=db,
    account_id=1,
    user_id=1
)
```

### JavaScript (Frontend)
```javascript
// الحصول على حساباتي
const response = await fetch('http://localhost:8000/api/my/accounts');
const accounts = await response.json();

// حذف حساب
await fetch(`http://localhost:8000/api/my/accounts/${accountId}`, {
  method: 'DELETE',
  headers: {
    'Authorization': `Bearer ${token}`
  }
});

// إحصائيات
const stats = await fetch('http://localhost:8000/api/my/accounts/stats');
```

---

## ✅ الميزات المكتملة

1. ✅ جدول `social_accounts` في قاعدة البيانات
2. ✅ خدمة `AccountService` لإدارة الحسابات
3. ✅ API endpoints للمستخدمين
4. ✅ API endpoints للإدارة
5. ✅ ربط تسجيل الدخول بقاعدة البيانات
6. ✅ حذف الحساب وملف الكوكيز
7. ✅ تتبع حالة الحساب
8. ✅ إحصائيات شاملة
9. ✅ نظام المحادثات محفوظ بالفعل

---

## 🚀 الخطوات التالية

### Frontend:
1. إنشاء صفحة `/accounts` لعرض الحسابات
2. إنشاء صفحة `/conversations` لعرض المحادثات
3. إنشاء لوحة تحكم إدارية `/admin/accounts`
4. إضافة مكونات UI للإحصائيات

### Backend:
1. إضافة دعم لمنصات أخرى (Instagram, Facebook)
2. إضافة جدولة المنشورات
3. إضافة تقارير وتحليلات

---

## 📞 الدعم

للمزيد من المعلومات أو المساعدة، راجع:
- `AGENTS_README.md` - نظام الوكلاء
- `X_INTEGRATION_README.md` - تكامل X
- `MEMORY_SYSTEM_README.md` - نظام الذاكرة

---

**النظام جاهز للاستخدام! 🎉**
