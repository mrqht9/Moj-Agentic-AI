# 🎯 Intent Recognition System API Documentation

## نظام التعرف على النوايا - دليل API

نظام ذكي للتعرف على نوايا المستخدم في إدارة حساباته على منصات التواصل الاجتماعي، مصمم للتكامل مع n8n Orchestra Agent.

---

## 📋 جدول المحتويات

1. [نظرة عامة](#نظرة-عامة)
2. [API Endpoints](#api-endpoints)
3. [النوايا المدعومة](#النوايا-المدعومة)
4. [أمثلة الاستخدام](#أمثلة-الاستخدام)
5. [التكامل مع n8n](#التكامل-مع-n8n)

---

## 🎯 نظرة عامة

### ما هو نظام النوايا؟

نظام النوايا (Intent System) هو محرك ذكاء اصطناعي يقوم بـ:
- **فهم نوايا المستخدم** من النص الطبيعي (عربي/إنجليزي)
- **استخراج الكيانات** المهمة من النص (أسماء حسابات، تواريخ، محتوى، إلخ)
- **تحديد المنصة** المستهدفة (Twitter, Instagram, Facebook, LinkedIn)
- **تقديم اقتراحات** للإجراءات التالية

### الميزات الرئيسية

✅ دعم اللغة العربية والإنجليزية  
✅ التعرف على 20+ نية مختلفة  
✅ استخراج ذكي للكيانات  
✅ دعم 5+ منصات تواصل اجتماعي  
✅ مستوى ثقة (Confidence Score) لكل نية  
✅ اقتراحات تلقائية للإجراءات  

---

## 🔌 API Endpoints

### Base URL
```
http://localhost:8000/api/intent
```

---

### 1. التعرف على النية

**POST** `/detect`

يحلل النص ويتعرف على نية المستخدم.

#### Request Body
```json
{
  "text": "أضف حساب تويتر الخاص بي",
  "context": {
    "user_id": 123,
    "session_id": "abc123"
  }
}
```

#### Response
```json
{
  "intent": "add_account",
  "confidence": 0.95,
  "entities": {
    "account_name": null
  },
  "platform": "twitter",
  "raw_text": "أضف حساب تويتر الخاص بي",
  "timestamp": "2026-01-12T18:30:00",
  "suggestions": [
    "قم بتوفير بيانات الاعتماد للحساب",
    "اختر المنصة: Twitter, Instagram, Facebook, LinkedIn"
  ]
}
```

#### مثال cURL
```bash
curl -X POST "http://localhost:8000/api/intent/detect" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "انشر تغريدة \"مرحباً بالجميع!\""
  }'
```

---

### 2. الحصول على اقتراحات

**POST** `/suggestions`

يعطي اقتراحات للنوايا بناءً على نص جزئي (مفيد للـ autocomplete).

#### Request Body
```json
{
  "partial_text": "أضف"
}
```

#### Response
```json
{
  "suggestions": [
    {
      "intent": "add_account",
      "example": "أضف حساب",
      "description": "إضافة حساب جديد على منصة التواصل"
    }
  ]
}
```

---

### 3. قائمة النوايا المدعومة

**GET** `/list`

يعرض جميع النوايا والمنصات المدعومة.

#### Response
```json
{
  "intents": [
    {
      "intent": "add_account",
      "description": "إضافة حساب جديد على منصة التواصل",
      "category": "account_management"
    },
    {
      "intent": "create_post",
      "description": "إنشاء ونشر منشور جديد",
      "category": "content_management"
    }
  ],
  "platforms": ["twitter", "x", "instagram", "facebook", "linkedin", "tiktok"]
}
```

---

### 4. معالجة دفعية

**POST** `/batch`

يعالج عدة نصوص دفعة واحدة.

#### Request Body
```json
{
  "requests": [
    {"text": "أضف حساب تويتر"},
    {"text": "انشر منشور على انستقرام"},
    {"text": "أرني الإحصائيات"}
  ]
}
```

---

## 📊 النوايا المدعومة

### 1️⃣ إدارة الحسابات (Account Management)

| النية | الوصف | أمثلة |
|-------|-------|-------|
| `add_account` | إضافة حساب جديد | "أضف حساب تويتر"، "ربط حساب انستقرام" |
| `remove_account` | حذف حساب | "احذف حساب فيسبوك"، "فك ربط الحساب" |
| `list_accounts` | عرض الحسابات | "اعرض حساباتي"، "قائمة الحسابات" |
| `switch_account` | التبديل بين الحسابات | "انتقل إلى حساب @username" |

### 2️⃣ إدارة المحتوى (Content Management)

| النية | الوصف | أمثلة |
|-------|-------|-------|
| `create_post` | إنشاء منشور | "انشر تغريدة"، "اكتب منشور" |
| `schedule_post` | جدولة منشور | "جدول منشور غداً"، "انشر بعد ساعتين" |
| `delete_post` | حذف منشور | "احذف آخر منشور" |
| `edit_post` | تعديل منشور | "عدل المنشور الأخير" |

### 3️⃣ التحليلات (Analytics)

| النية | الوصف | أمثلة |
|-------|-------|-------|
| `get_analytics` | عرض الإحصائيات | "أرني الإحصائيات"، "تحليلات الحساب" |
| `get_engagement` | معدل التفاعل | "ما هو معدل التفاعل؟" |
| `get_followers` | عدد المتابعين | "كم عدد المتابعين؟" |

### 4️⃣ التفاعل (Interaction)

| النية | الوصف | أمثلة |
|-------|-------|-------|
| `reply_to_comment` | الرد على تعليق | "رد على آخر تعليق" |
| `like_post` | إعجاب بمنشور | "أعجبني المنشور" |
| `share_post` | مشاركة منشور | "شارك المنشور" |

### 5️⃣ الأتمتة (Automation)

| النية | الوصف | أمثلة |
|-------|-------|-------|
| `create_automation` | إنشاء أتمتة | "أتمت النشر اليومي" |
| `manage_automation` | إدارة الأتمتة | "أوقف الأتمتة" |

---

## 💡 أمثلة الاستخدام

### مثال 1: إضافة حساب

**Input:**
```
"أضف حساب تويتر @myusername"
```

**Output:**
```json
{
  "intent": "add_account",
  "confidence": 0.95,
  "platform": "twitter",
  "entities": {
    "account_name": "myusername"
  }
}
```

### مثال 2: نشر محتوى

**Input:**
```
"انشر على انستقرام 'صباح الخير! يوم جميل اليوم'"
```

**Output:**
```json
{
  "intent": "create_post",
  "confidence": 0.92,
  "platform": "instagram",
  "entities": {
    "post_content": "صباح الخير! يوم جميل اليوم"
  }
}
```

### مثال 3: جدولة منشور

**Input:**
```
"جدول منشور على تويتر غداً الساعة 10 صباحاً"
```

**Output:**
```json
{
  "intent": "schedule_post",
  "confidence": 0.90,
  "platform": "twitter",
  "entities": {
    "schedule_time": {
      "type": "tomorrow",
      "value": "غداً"
    }
  }
}
```

---

## 🔗 التكامل مع n8n Orchestra Agent

### خطوات التكامل

#### 1. إنشاء HTTP Request Node في n8n

```javascript
// n8n HTTP Request Node Configuration
{
  "method": "POST",
  "url": "http://localhost:8000/api/intent/detect",
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "text": "{{ $json.user_message }}"
  }
}
```

#### 2. معالجة الاستجابة

```javascript
// n8n Function Node - Process Intent
const intent = $input.item.json.intent;
const platform = $input.item.json.platform;
const entities = $input.item.json.entities;
const confidence = $input.item.json.confidence;

// توجيه المستخدم حسب النية
if (confidence < 0.7) {
  return {
    action: "clarify",
    message: "عذراً، لم أفهم طلبك. هل يمكنك إعادة الصياغة؟"
  };
}

switch(intent) {
  case "add_account":
    return {
      action: "add_account_flow",
      platform: platform,
      next_step: "request_credentials"
    };
  
  case "create_post":
    return {
      action: "create_post_flow",
      platform: platform,
      content: entities.post_content,
      next_step: "confirm_post"
    };
  
  case "get_analytics":
    return {
      action: "analytics_flow",
      platform: platform,
      next_step: "fetch_analytics"
    };
  
  default:
    return {
      action: "unknown",
      message: "هذه الميزة قيد التطوير"
    };
}
```

#### 3. مثال Workflow كامل في n8n

```
[User Input] 
    ↓
[Intent Detection API]
    ↓
[Process Intent]
    ↓
[Switch Node - Based on Intent]
    ↓
├─→ [Add Account Flow]
├─→ [Create Post Flow]
├─→ [Analytics Flow]
└─→ [Help Flow]
```

---

## 🧪 الاختبار

### تشغيل الاختبارات

```bash
# اختبار نظام النوايا
python test_intent_system.py

# تشغيل Backend
python run.py
```

### اختبار من المتصفح

افتح Swagger UI:
```
http://localhost:8000/docs
```

---

## 📝 ملاحظات مهمة

1. **مستوى الثقة (Confidence):**
   - `0.9 - 1.0`: ثقة عالية جداً
   - `0.7 - 0.9`: ثقة جيدة
   - `< 0.7`: يُنصح بطلب توضيح من المستخدم

2. **استخراج الكيانات:**
   - يتم استخراج الكيانات تلقائياً من النص
   - الكيانات تشمل: أسماء حسابات، تواريخ، محتوى، أرقام

3. **دعم اللغات:**
   - العربية: دعم كامل
   - الإنجليزية: دعم كامل
   - يمكن خلط اللغتين في نفس النص

---

## 🚀 التطوير المستقبلي

- [ ] دعم المزيد من المنصات (YouTube, Snapchat)
- [ ] تحسين دقة التعرف باستخدام ML Models
- [ ] دعم الأوامر الصوتية
- [ ] Context-aware intent detection
- [ ] Multi-turn conversation support

---

## 📞 الدعم

للمساعدة أو الاستفسارات:
- افتح Issue على GitHub
- راجع الوثائق الكاملة
- اختبر النظام باستخدام `test_intent_system.py`

---

**تم إنشاء هذا النظام بواسطة:** موج AI - نظام إدارة وسائل التواصل الاجتماعي  
**الإصدار:** 1.0.0  
**التاريخ:** يناير 2026
